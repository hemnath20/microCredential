package com.casestudy.automated.premiums.AutomatedPremiumsClaims.DAO;

import java.util.List;
import java.util.Optional;

import org.hibernate.Hibernate;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;

import com.casestudy.automated.premiums.AutomatedPremiumsClaims.model.CustomerDetails;



@Component
@Repository
public interface CustomerDetailsRepository extends CrudRepository<CustomerDetails,Long> {
	
	List<CustomerDetails> findAll();
	Optional<CustomerDetails> findByName(String name);
	
	
	
}
