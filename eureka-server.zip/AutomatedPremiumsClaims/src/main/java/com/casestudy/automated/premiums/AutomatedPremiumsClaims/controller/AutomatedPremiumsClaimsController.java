package com.casestudy.automated.premiums.AutomatedPremiumsClaims.controller;


import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Optional;
import java.util.function.Function;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.casestudy.automated.premiums.AutomatedPremiumsClaims.DAO.CustomerDetailsRepository;
import com.casestudy.automated.premiums.AutomatedPremiumsClaims.model.CustomerDetails;
import com.casestudy.automated.premiums.AutomatedPremiumsClaims.model.PolicyDetails;
import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;



@RestController
public class AutomatedPremiumsClaimsController {
	private Logger logger = LoggerFactory.getLogger(this.getClass());
	
	@Autowired
	CustomerDetailsRepository calculatepremiumdao;
	
	@Autowired
	Optional<CustomerDetails> person;	
	
	
	
	
	
	
	@RequestMapping(value="/premiumcalculation/{ssn}",method = RequestMethod.GET)
	@HystrixCommand(fallbackMethod = "getDataFallBack")
	public Optional<CustomerDetails> premiumCalculation(@PathVariable Long ssn) {
		 logger.info("Inside PremiumCalculation method starts ");
		 person = calculatepremiumdao.findById(ssn);	
		 logger.info("Inside PremiumCalculation method starts ");
		 return person;
	}
	
	
	
	  public Optional<CustomerDetails> getDataFallBack(@PathVariable Long ssn) {
		  logger.info("Inside PremiumCalculation Fallback method starts ");
		  Optional<CustomerDetails> optional = Optional.empty();
		  CustomerDetails fallback = new CustomerDetails();
		  PolicyDetails policy = new PolicyDetails();
		  List<PolicyDetails> policylist = new ArrayList();
		  fallback.setAge(1);
		  fallback.setCustomer_details_id(1L);
		  fallback.setGender("fallback-gender");
		  fallback.setMailAddress("fallback-mailaddress");
		  fallback.setName("fallback-name");
		  policy.setDueDate(new Date());
		  policy.setPaidDate(new Date());
		  policy.setPolicy_details_id(1L);
		  policy.setPolicyType("fallback-policytype");
		  policy.setPremiumAmountToBePaid(00.0);
		  policy.setSsn(1L);
		  policy.setTotalPolicyAmount(00.0);
		  policy.setTotalpolicyamountpaid(00.0);
		  policylist.add(policy); 
		  fallback.setPolicydetails(policylist);
		  logger.info("Inside PremiumCalculation Fallback method ends ");
		  return  Optional.ofNullable(optional.orElse(fallback)); 
	  }
	 	 
	
	
	

		
}


