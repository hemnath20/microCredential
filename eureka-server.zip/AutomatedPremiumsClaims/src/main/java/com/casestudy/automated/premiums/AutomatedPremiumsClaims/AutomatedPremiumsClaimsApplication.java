package com.casestudy.automated.premiums.AutomatedPremiumsClaims;



import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.circuitbreaker.EnableCircuitBreaker;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;



@SpringBootApplication
@EnableCircuitBreaker
@EnableDiscoveryClient
public class AutomatedPremiumsClaimsApplication {

	public static void main(String[] args) {
		SpringApplication.run(AutomatedPremiumsClaimsApplication.class, args);
	}

	
	/*
	 * @PostConstruct public void init() {
	 * 
	 * calculatePremiumDAO.save(new
	 * CustomerDetails(1L,"xyz",24,"male","health",7500.00,Month.of(8),false,
	 * "microservicetesting1@gmail.com")); calculatePremiumDAO.save(new
	 * CustomerDetails(10001L,"arun",24,"male","job",5500.00,Month.of(8),false,
	 * "arun@gmail.com")); calculatePremiumDAO.save(new
	 * CustomerDetails(10002L,"aruna",25,"female","study",6500.00,Month.of(8),false,
	 * "aruna@gmail.com")); calculatePremiumDAO.save(new
	 * CustomerDetails(10003L,"vijay",25,"male","retirement",4500.00,Month.of(8),
	 * false,"vijay@gmail.com"));
	 * 
	 * }
	 * 
	 * @Autowired CalculatePremiumDAO calculatePremiumDAO;
	 */
}
