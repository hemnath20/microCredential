package com.casestudy.automated.premiums.AutomatedPremiumsClaims;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AutomatedPremiumsClaimsApplicationTests {

	@Test
	void contextLoads() {
	}

}
