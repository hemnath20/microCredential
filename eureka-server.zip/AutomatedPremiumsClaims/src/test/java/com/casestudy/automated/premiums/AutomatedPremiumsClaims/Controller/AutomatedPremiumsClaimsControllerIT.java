package com.casestudy.automated.premiums.AutomatedPremiumsClaims.Controller;

import static org.junit.jupiter.api.Assertions.*;

import java.util.Collection;
import java.util.List;



import org.assertj.core.util.Arrays;
import org.json.JSONException;
import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.skyscreamer.jsonassert.JSONAssert;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.boot.web.server.LocalServerPort;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit4.SpringRunner;

import com.casestudy.automated.premiums.AutomatedPremiumsClaims.AutomatedPremiumsClaimsApplication;




@RunWith(SpringRunner.class)
@SpringBootTest(classes = AutomatedPremiumsClaimsApplication.class, webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
public class AutomatedPremiumsClaimsControllerIT {

	@LocalServerPort
	private int port;
	
	@Test
	void test() throws JSONException {
		String url = "http://localhost:"+port+"/premiumcalculation/123";
		TestRestTemplate restTemplate = new TestRestTemplate();
		//String outputDo = restTemplate.getForObject(url, String.class);
		HttpHeaders headers = new HttpHeaders();
		
		headers.set("Content-Type","application/json");
		headers.set("Accept", "application/json");
		HttpEntity entity = new HttpEntity<String>(null,headers);
		ResponseEntity<String> response = restTemplate.exchange(url,HttpMethod.GET,entity , String.class);		
		String expected = "{\"ssn\":123,\"customer_details_id\":1,\"name\":\"xyz\",\"age\":24,\"gender\":\"male\",\"mailAddress\":\"microservicetesting1@gmail.com\",\"policydetails\":[{\"policy_details_id\":1,\"ssn\":123,\"policyType\":\"PFL\",\"totalPolicyAmount\":100000.0,\"premiumAmountToBePaid\":10000.0,\"dueDate\":\"2024-01-22T18:30:00.000+00:00\",\"paidDate\":\"2020-10-08T17:13:27.000+00:00\",\"totalpolicyamountpaid\":100000.0},{\"policy_details_id\":2,\"ssn\":123,\"policyType\":\"STD\",\"totalPolicyAmount\":200000.0,\"premiumAmountToBePaid\":20000.0,\"dueDate\":\"2022-06-02T18:30:00.000+00:00\",\"paidDate\":\"2020-10-06T14:03:12.000+00:00\",\"totalpolicyamountpaid\":200000.0}]}";
		System.out.println("Response Output "+response.getBody());
		JSONAssert.assertEquals(expected,response.getBody(), false);
	}

}
