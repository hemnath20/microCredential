package com.casestudy.automated.premiums.FileAClaim.Repository;

import java.util.List;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;

import com.casestudy.automated.premiums.FileAClaim.model.CustomerDetails;






@Component
@Repository
public interface CustomerDetailsRepository extends CrudRepository<CustomerDetails,Long> {
	
	List<CustomerDetails> findAll();
	CustomerDetails findByName(String name);
	
}
