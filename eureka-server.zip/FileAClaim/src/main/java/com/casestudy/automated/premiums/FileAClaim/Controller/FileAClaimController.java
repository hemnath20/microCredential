package com.casestudy.automated.premiums.FileAClaim.Controller;

import java.util.List;
import java.util.Optional;
import java.util.Properties;

import javax.mail.Address;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.AddressException;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.casestudy.automated.premiums.FileAClaim.Authentication.GMailAuthenticator;
import com.casestudy.automated.premiums.FileAClaim.Repository.ClaimDetailsRepository;
import com.casestudy.automated.premiums.FileAClaim.Repository.CustomerDetailsRepository;
import com.casestudy.automated.premiums.FileAClaim.Service.FileAClaimService;
import com.casestudy.automated.premiums.FileAClaim.model.CustomerDetails;
import com.casestudy.automated.premiums.FileAClaim.model.FileAClaimDO;
import com.casestudy.automated.premiums.FileAClaim.model.FileClaim;
import com.casestudy.automated.premiums.FileAClaim.model.MessageResponseDO;
import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;






@RestController
public class FileAClaimController {
	
	private Logger logger = LoggerFactory.getLogger(this.getClass());
	
	@Autowired 
	FileAClaimService claimservice;
	
	@Autowired
	FileClaim fileclaim;
	
	@Autowired
	MessageResponseDO responseDo;
	
	@Autowired
	ClaimDetailsRepository fileRepository;
	
	@Autowired
	CustomerDetailsRepository customerRepository;
	
	@Autowired
	List<FileClaim> claimdetails;
	
	@Autowired
	List<CustomerDetails> customerdetails;
	
	@RequestMapping(value="/fileAclaim",method = RequestMethod.POST)
	@HystrixCommand(fallbackMethod = "getDataFallBack")
	public MessageResponseDO fileAClaim(@RequestBody FileAClaimDO details) {
		logger.info("File a claim service starts");
		Long ssn = details.getSsn();
		String policytype = details.getPolicytype();		
		responseDo = claimservice.fileaClaim(ssn,policytype);
		logger.info("File a claim service ends");
		return responseDo;

	}
	
	public MessageResponseDO getDataFallBack(@RequestBody FileAClaimDO details) {
		logger.info("Inside File a claim service fall back method");
		responseDo.setMessage("fallBack");
		 return responseDo;
	}
	
	@Scheduled(cron = "0,20 * * * * *")
	public void sentmail() {
		logger.info("Sending mail method starts");
		customerdetails = customerRepository.findAll();
		claimdetails = (List<FileClaim>) fileRepository.findAll();
		for(FileClaim detail:claimdetails) {
		if(detail.getIsclaimsubmitted().equalsIgnoreCase("submitted") && null == detail.getIsclaimprocessed()) {
		String host = "smtp.gmail.com";	 
		Transport transport = null;
        Properties props = System.getProperties();
        props.put("mail.smtp.starttls.enable", "true");
        props.put("mail.smtp.host", host);	        
        props.put("mail.smtp.port", "587");
        props.put("mail.smtp.auth", "true");
        props.put("mail.debug", "true");
        
        Session session = Session.getInstance(props, new GMailAuthenticator("microservicetesting@gmail.com", "sharmila281995"));
        try {
        transport = session.getTransport("smtp");
		System.out.print("is connected " +transport.isConnected());
        } catch (MessagingException e) {
			logger.info("Exception caught while fetching smtp transport ", e.getMessage());
		}
		
		if (null != detail.getMailAddress()) {
			
	        MimeMessage message = new MimeMessage(session);
	        Address fromAddress = null;
	        Address toAddress = null;
			try {
				fromAddress = new InternetAddress("microservicetesting@gmail.com");      
			
				toAddress = new InternetAddress(detail.getMailAddress());
			} catch (AddressException e) {
				logger.info("Exception caught while fetching the mail address ",e.getMessage());
			}

	        try {
				message.setFrom(fromAddress);
			
				message.setRecipient(Message.RecipientType.TO, toAddress);
			
				message.setSubject("Claim Processed Successfully");
			
				message.setText("Your claim has been successfully processed!");
			} catch (MessagingException e) {
				logger.info("Exception caught while parsing the mail content ",e.getMessage());
			}	
	       
			
	        try {			
	        message.saveChanges();	       
	        Transport.send(message);
		} catch (MessagingException e) {
			logger.info("Exception caught while sending the mail ",e.getMessage());
			e.printStackTrace();
		} 
	        fileclaim.setPolicyType(detail.getPolicyType());
	        fileclaim.setSsn(detail.getSsn());
	        fileclaim.setIsmailsent("sent");
	        fileclaim.setIsclaimprocessed("processed");
	        fileRepository.save(fileclaim);
	        logger.info("Mail has been sent successfully");
		
		}	 	
		
	try {
			transport.close();
		} catch (MessagingException e) {
			logger.info("Exception occurred while closing the transport ", e.getMessage());
		}
		
		
		} else {
			logger.info("Mail Address is not available");
		}
		
		}
		logger.info("Sending mail method ends");
	}
 }

