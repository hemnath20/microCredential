package com.casestudy.automated.premiums.FileAClaim.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.springframework.stereotype.Component;

@Component
@Entity
@Table(name = "file_claim")
public class FileClaim {
	
	@Id	
	@Column(name = "ssn")
	private Long ssn;
	

	@Column(name = "policytype")
	private String policyType;
	
	@Column(name = "isclaimsubmitted")
	private String isclaimsubmitted;
	
	@Column(name = "ismailsent")
	private String ismailsent;
	
	@Column(name = "isclaimprocessed")
	private String isclaimprocessed;	
	
	@Column(name = "mailaddress")
	private String mailAddress;
	

	public FileClaim() {
		
	}	




	public FileClaim(Long ssn, String policyType, String isclaimsubmitted, String ismailsent, String isclaimprocessed,
			String mailAddress) {
		this();
		this.ssn = ssn;
		this.policyType = policyType;
		this.isclaimsubmitted = isclaimsubmitted;
		this.ismailsent = ismailsent;
		this.isclaimprocessed = isclaimprocessed;
		this.mailAddress = mailAddress;
	}





	public String getPolicyType() {
		return policyType;
	}

	public void setPolicyType(String policyType) {
		this.policyType = policyType;
	}

	
	
	public String getIsclaimsubmitted() {
		return isclaimsubmitted;
	}






	public void setIsclaimsubmitted(String isclaimsubmitted) {
		this.isclaimsubmitted = isclaimsubmitted;
	}






	public String getIsmailsent() {
		return ismailsent;
	}






	public void setIsmailsent(String ismailsent) {
		this.ismailsent = ismailsent;
	}






	public String getIsclaimprocessed() {
		return isclaimprocessed;
	}






	public void setIsclaimprocessed(String isclaimprocessed) {
		this.isclaimprocessed = isclaimprocessed;
	}


	public Long getSsn() {
		return ssn;
	}

	public void setSsn(Long ssn) {
		this.ssn = ssn;
	}






	public String getMailAddress() {
		return mailAddress;
	}






	public void setMailAddress(String mailAddress) {
		this.mailAddress = mailAddress;
	}

	
	
	

}
