package com.casestudy.automated.premiums.FileAClaim.Service;

import java.time.LocalDate;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;


import com.casestudy.automated.premiums.FileAClaim.Repository.ClaimDetailsRepository;
import com.casestudy.automated.premiums.FileAClaim.Repository.CustomerDetailsRepository;
import com.casestudy.automated.premiums.FileAClaim.model.CustomerDetails;
import com.casestudy.automated.premiums.FileAClaim.model.FileClaim;
import com.casestudy.automated.premiums.FileAClaim.model.MessageResponseDO;
import com.casestudy.automated.premiums.FileAClaim.model.PolicyDetails;




@Component
public class FileAClaimService {
	private Logger logger = LoggerFactory.getLogger(this.getClass());
	
	@Autowired
	CustomerDetailsRepository customerRepository;
	
	@Autowired
	Optional<CustomerDetails> customerDetails;
	
	@Autowired
	PolicyDetails policyDo;
	
	@Autowired
	ClaimDetailsRepository claimdetailsrepository;
	
	@Autowired
	Optional<FileClaim> fileClaim;
	
	
	@Autowired 
	FileClaim submitclaim;
	
	@Autowired
	MessageResponseDO responseDo;
	
	
	
	
	
	public MessageResponseDO fileaClaim(Long ssn,String policytype) {
		logger.info("Inside FileAClaimService method starts ");
		customerDetails = customerRepository.findById(ssn);
		fileClaim = claimdetailsrepository.findById(ssn);		
			if(customerDetails.isPresent()) {
					if(!fileClaim.isPresent() || (!fileClaim.get().getPolicyType().equalsIgnoreCase(policytype))) {
							for(PolicyDetails policy : customerDetails.get().getPolicydetails()) {
								if((policy.getSsn() == ssn) && (policy.getPolicyType().equalsIgnoreCase(policytype))) {			
									//fileClaim.setIsclaimprocessed(true);
									submitclaim.setIsclaimsubmitted("Submitted");
									submitclaim.setPolicyType(policytype);
									submitclaim.setSsn(ssn);
									submitclaim.setMailAddress(customerDetails.get().getMailAddress());
									claimdetailsrepository.save(submitclaim);
									responseDo.setMessage("Claim has been Submiited successfully");
									}
							}							
							if(null == responseDo.getMessage()) {
								responseDo.setMessage("Claim Submission has been failed");
							}
							
					} else {
						responseDo.setMessage("Claim has been already submitted");
					}				
			}else {
			responseDo.setMessage("The user does not exist");
		}
			logger.info("Inside FileAClaimService method ends ");
		return responseDo;
	}
	
	

}
