package com.casestudy.automated.premiums.FileAClaim.model;

import org.springframework.stereotype.Component;

@Component
public class FileAClaimDO {
	
	private Long ssn;
	public String policytype;
	
	
	
	
	
	public FileAClaimDO() {
		super();
	}
	
	
	public FileAClaimDO(Long ssn, String policytype) {
		super();
		this.ssn = ssn;
		this.policytype = policytype;
	}


	public Long getSsn() {
		return ssn;
	}
	public void setSsn(Long ssn) {
		this.ssn = ssn;
	}
	public String getPolicytype() {
		return policytype;
	}
	public void setPolicytype(String policytype) {
		this.policytype = policytype;
	}
	
	

}
