package com.casestudy.automated.premiums.FileAClaim.model;

import java.util.Date;


import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.springframework.stereotype.Component;



@Component
@Entity
@Table(name = "policy_details")
public class PolicyDetails {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "policy_details_id")
	Long policy_details_id;
	
		
	@Column(name = "ssn")
	private Long ssn;	
	
	
	@Column(name = "policytype")
	private String policyType;
	
	@Column(name = "totalpolicyamount")
	private double totalPolicyAmount;
	
	@Column(name = "premiumamount")
	private double premiumAmountToBePaid;
	
	@Column(name = "duedate")
	private Date dueDate;
	
	
	@Column(name = "paiddate")
	private Date paidDate;

	@Column(name = "totalpolicyamountpaid")
	private double totalpolicyamountpaid;
	



	public double getTotalpolicyamountpaid() {
		return totalpolicyamountpaid;
	}


	public void setTotalpolicyamountpaid(double totalpolicyamountpaid) {
		this.totalpolicyamountpaid = totalpolicyamountpaid;
	}


	public Long getPolicy_details_id() {
		return policy_details_id;
	}


	public void setPolicy_details_id(Long policy_details_id) {
		this.policy_details_id = policy_details_id;
	}


	


	public Long getSsn() {
		return ssn;
	}


	public void setSsn(Long ssn) {
		this.ssn = ssn;
	}


	public String getPolicyType() {
		return policyType;
	}


	public void setPolicyType(String policyType) {
		this.policyType = policyType;
	}


	public double getTotalPolicyAmount() {
		return totalPolicyAmount;
	}


	public void setTotalPolicyAmount(double totalPolicyAmount) {
		this.totalPolicyAmount = totalPolicyAmount;
	}


	public double getPremiumAmountToBePaid() {
		return premiumAmountToBePaid;
	}


	public void setPremiumAmountToBePaid(double premiumAmountToBePaid) {
		this.premiumAmountToBePaid = premiumAmountToBePaid;
	}


	public Date getDueDate() {
		return dueDate;
	}


	public void setDueDate(Date dueDate) {
		this.dueDate = dueDate;
	}


	public Date getPaidDate() {
		return paidDate;
	}


	public void setPaidDate(Date paidDate) {
		this.paidDate = paidDate;
	}


	
	
	 
	
	
	

}
