package com.casestudy.automated.premiums.FileAClaim.model;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import org.springframework.stereotype.Component;



@Component
@Entity
@Table(name = "customer_details")
public class CustomerDetails {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "ssn")
	private Long ssn;
	
	
	@Column(name = "customer_details_id")
	private Long customer_details_id;
	
	
	
	@Column(name = "name")
	private String name;
	
	@Column(name = "age")
	private int age;
	
	@Column(name = "gender")
	private String gender;
	
	@Column(name = "mailaddress")
	private String mailAddress;
	
	
	@OneToMany(mappedBy = "ssn",cascade = CascadeType.ALL,fetch = FetchType.EAGER)
	private List<PolicyDetails> policydetails;


	


	public Long getCustomer_details_id() {
		return customer_details_id;
	}


	public void setCustomer_details_id(Long customer_details_id) {
		this.customer_details_id = customer_details_id;
	}

	


	public Long getSsn() {
		return ssn;
	}


	public void setSsn(Long ssn) {
		this.ssn = ssn;
	}


	public String getName() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}


	public int getAge() {
		return age;
	}


	public void setAge(int age) {
		this.age = age;
	}


	public String getGender() {
		return gender;
	}


	public void setGender(String gender) {
		this.gender = gender;
	}


	public String getMailAddress() {
		return mailAddress;
	}


	public void setMailAddress(String mailAddress) {
		this.mailAddress = mailAddress;
	}


	public List<PolicyDetails> getPolicydetails() {
		return policydetails;
	}


	public void setPolicydetails(List<PolicyDetails> policydetails) {
		this.policydetails = policydetails;
	}
	
	
	

}
