package com.casestudy.automated.premiums.FileAClaim.Controller;

import static org.junit.jupiter.api.Assertions.*;

import org.assertj.core.util.Arrays;
import org.json.JSONException;
import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.skyscreamer.jsonassert.JSONAssert;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.boot.web.server.LocalServerPort;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit4.SpringRunner;


import com.casestudy.automated.premiums.FileAClaim.FileAClaimApplication;
import com.casestudy.automated.premiums.FileAClaim.model.FileAClaimDO;



@RunWith(SpringRunner.class)
@SpringBootTest(classes = FileAClaimApplication.class, webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
public class FileAClaimControllerIT {

	@LocalServerPort
	private int port;
	
	@Test
	void test() throws JSONException {
		String url = "http://localhost:"+port+"/fileAclaim";
		TestRestTemplate restTemplate = new TestRestTemplate();
		FileAClaimDO claimdo = new FileAClaimDO(123L,"PFL");
		HttpHeaders headers = new HttpHeaders();
		headers.set("Content-Type","application/json");
		headers.set("Accept", "application/json");
		HttpEntity entity = new HttpEntity<>(claimdo,headers);
		ResponseEntity<String> response = restTemplate.exchange(url,HttpMethod.POST,entity , String.class);	
		String expected = "{\"message\":\"Claim has been already submitted\"}";
		System.out.println("Response: "+response.getBody());
		JSONAssert.assertEquals(expected,response.getBody(), false);
	}

}
