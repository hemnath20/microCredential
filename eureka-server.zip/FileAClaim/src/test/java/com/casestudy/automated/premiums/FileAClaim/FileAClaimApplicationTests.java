package com.casestudy.automated.premiums.FileAClaim;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;


@SpringBootTest
public class FileAClaimApplicationTests {

	@Test
	void contextLoads() {
	}

}
