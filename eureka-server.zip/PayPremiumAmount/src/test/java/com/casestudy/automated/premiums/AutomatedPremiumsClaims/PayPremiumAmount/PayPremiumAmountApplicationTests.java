package com.casestudy.automated.premiums.AutomatedPremiumsClaims.PayPremiumAmount;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PayPremiumAmountApplicationTests {

	@Test
	void contextLoads() {
	}

}
