package com.casestudy.automated.premiums.AutomatedPremiumsClaims.PayPremiumAmountController;

import static org.junit.jupiter.api.Assertions.*;

import org.json.JSONException;
import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.skyscreamer.jsonassert.JSONAssert;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.boot.web.server.LocalServerPort;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit4.SpringRunner;


import com.casestudy.automated.premiums.AutomatedPremiumsClaims.PayPremiumAmount.PayPremiumAmountApplication;
import com.casestudy.automated.premiums.AutomatedPremiumsClaims.PayPremiumAmount.model.PaymentDetail;


@RunWith(SpringRunner.class)
@SpringBootTest(classes = PayPremiumAmountApplication.class, webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
public class PayPremiumAmountControllerIT {
	
	@LocalServerPort
	private int port;

	@Test
	void test() throws JSONException {
		String url = "http://localhost:"+port+"/paypremiumamount";
		TestRestTemplate restTemplate = new TestRestTemplate();
		
		PaymentDetail paymentdetail = new PaymentDetail(102L,"STD",5000.0,"Card","474763738");
		//String outputDo = restTemplate.getForObject(url, String.class);
		HttpHeaders headers = new HttpHeaders();
		
		headers.set("Content-Type","application/json");
		headers.set("Accept", "application/json");
		HttpEntity entity = new HttpEntity<PaymentDetail>(paymentdetail,headers);
		ResponseEntity<String> response = restTemplate.exchange(url,HttpMethod.POST,entity , String.class);		
		String expected = "{\"message\":\"Premium Amount has been paid successfully\"}";
		System.out.println("Response Output "+response.getBody());
		JSONAssert.assertEquals(expected,response.getBody(), false);
	}

}
