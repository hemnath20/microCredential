package com.casestudy.automated.premiums.AutomatedPremiumsClaims.PayPremiumAmount.Repository;

import java.util.List;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.casestudy.automated.premiums.AutomatedPremiumsClaims.PayPremiumAmount.model.TransactionalDetails;

@Repository
public interface TransactionRepository extends CrudRepository<TransactionalDetails,Long> {

	List<TransactionalDetails> findAll();
	

}
