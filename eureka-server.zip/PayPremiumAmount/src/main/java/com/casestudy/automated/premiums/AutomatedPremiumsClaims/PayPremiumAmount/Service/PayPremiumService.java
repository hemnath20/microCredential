package com.casestudy.automated.premiums.AutomatedPremiumsClaims.PayPremiumAmount.Service;


import java.util.Calendar;
import java.util.Date;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;



import com.casestudy.automated.premiums.AutomatedPremiumsClaims.PayPremiumAmount.Repository.CustomerDetailsRepository;
import com.casestudy.automated.premiums.AutomatedPremiumsClaims.PayPremiumAmount.Repository.PolicyRepository;
import com.casestudy.automated.premiums.AutomatedPremiumsClaims.PayPremiumAmount.Repository.TransactionRepository;
import com.casestudy.automated.premiums.AutomatedPremiumsClaims.PayPremiumAmount.model.CustomerDetails;
import com.casestudy.automated.premiums.AutomatedPremiumsClaims.PayPremiumAmount.model.MessageResponseDO;
import com.casestudy.automated.premiums.AutomatedPremiumsClaims.PayPremiumAmount.model.PolicyDetails;
import com.casestudy.automated.premiums.AutomatedPremiumsClaims.PayPremiumAmount.model.TransactionalDetails;



@Component
public class PayPremiumService {
	
	
	@Autowired
	PolicyDetails policydo;
	
	@Autowired
	TransactionalDetails transactiondetails;
	
	@Autowired
	Optional<CustomerDetails> customerDetails;
	
	@Autowired
	PolicyRepository policyrepository;
	
	@Autowired
	MessageResponseDO responseDo;
	
	@Autowired
	TransactionRepository transactionrepository;
	
	@Autowired
	CustomerDetailsRepository calculatepremiumdao;
	
	public MessageResponseDO payPremiummethod(Long ssn,String policytype,double amount,String paymentType, String cardNumber)
	{		
		//details = policyrepository.findBySSN(ssn);
		customerDetails = calculatepremiumdao.findById(ssn);
		if(customerDetails.isEmpty()) {
			responseDo.setMessage("The user doesn't exist");
			return responseDo;
		}
		if(customerDetails.isPresent()) {
		for(PolicyDetails detail:customerDetails.get().getPolicydetails()) {
		if(detail.getPolicyType().equalsIgnoreCase(policytype)) {	
			if(detail.getPremiumAmountToBePaid() == amount) {
			//SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
			double totalpolicyamountpaid = policydo.getTotalpolicyamountpaid() + amount;
			Calendar c = Calendar.getInstance();
			c.setTime(detail.getDueDate());
			c.add(Calendar.DAY_OF_MONTH, 30);
			transactiondetails.setSsn(ssn);
			transactiondetails.setPaymenttype(paymentType);
			transactiondetails.setPremiumamountpaid(amount);
			transactiondetails.setCardnumber(cardNumber);
			transactiondetails.setPolicytype(policytype);
			transactiondetails.setTransactioncompleted(true);			
			transactionrepository.save(transactiondetails);
			policydo.setPaidDate(new Date());
			policydo.setDueDate(c.getTime());
			policydo.setTotalpolicyamountpaid(totalpolicyamountpaid);
			policydo.setPolicy_details_id(detail.getPolicy_details_id());
			policydo.setPolicyType(detail.getPolicyType());
			policydo.setPremiumAmountToBePaid(detail.getPremiumAmountToBePaid());
			policydo.setSsn(detail.getSsn());
			policydo.setTotalPolicyAmount(detail.getTotalPolicyAmount());
			policyrepository.save(policydo);
			 responseDo.setMessage("Premium Amount has been paid successfully");
			} else {
			 responseDo.setMessage("Please pay the correct premium amount");
			 break;
			}
		}
	}
		}
		if(null == responseDo.getMessage()) {
			 responseDo.setMessage("Premium Amount Payment has been failed");
		}
		return responseDo;		
	}
	
	
}
