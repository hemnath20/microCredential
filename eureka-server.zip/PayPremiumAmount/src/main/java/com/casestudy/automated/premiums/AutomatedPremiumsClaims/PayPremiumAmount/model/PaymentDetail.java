package com.casestudy.automated.premiums.AutomatedPremiumsClaims.PayPremiumAmount.model;

import org.springframework.stereotype.Component;

@Component
public class PaymentDetail {
	
	private Long ssn;
	
	private String policyType;
	
	private Double premiumAmount;
	
	private String paymentType;
	
	private String cardNumber;
	
	
	public PaymentDetail() {
		
	}

	

	public PaymentDetail(Long ssn, String policyType, Double premiumAmount, String paymentType, String cardNumber) {
		this();
		this.ssn = ssn;
		this.policyType = policyType;
		this.premiumAmount = premiumAmount;
		this.paymentType = paymentType;
		this.cardNumber = cardNumber;
	}



	public Long getSsn() {
		return ssn;
	}

	public void setSsn(Long ssn) {
		this.ssn = ssn;
	}

	public String getPolicyType() {
		return policyType;
	}

	public void setPolicyType(String policyType) {
		this.policyType = policyType;
	}

	public Double getPremiumAmount() {
		return premiumAmount;
	}

	public void setPremiumAmount(Double premiumAmount) {
		this.premiumAmount = premiumAmount;
	}



	public String getPaymentType() {
		return paymentType;
	}



	public void setPaymentType(String paymentType) {
		this.paymentType = paymentType;
	}



	public String getCardNumber() {
		return cardNumber;
	}



	public void setCardNumber(String cardNumber) {
		this.cardNumber = cardNumber;
	}
	
	

}
