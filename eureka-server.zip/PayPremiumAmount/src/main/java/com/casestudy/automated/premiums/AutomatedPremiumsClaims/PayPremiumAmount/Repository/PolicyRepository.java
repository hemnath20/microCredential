package com.casestudy.automated.premiums.AutomatedPremiumsClaims.PayPremiumAmount.Repository;



import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;
import java.util.Optional;
import com.casestudy.automated.premiums.AutomatedPremiumsClaims.PayPremiumAmount.model.PolicyDetails;




@Component
@Repository
public interface PolicyRepository extends CrudRepository<PolicyDetails,Long>{
	
	
	@Query("Select u from PolicyDetails u where u.ssn='ssn'")
	Optional<PolicyDetails> findBySSN(Long ssn);



}
