package com.casestudy.automated.premiums.AutomatedPremiumsClaims.PayPremiumAmount.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.springframework.stereotype.Component;

@Component
@Entity
@Table(name = "transaction_details")
public class TransactionalDetails {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "transaction_details_id")
	private Long transaction_details_id;
	
	@Column(name = "ssn")
	private Long ssn;
	
	@Column(name = "policytype")
	private String policytype;
	
	@Column(name = "paymenttype")
	private String paymenttype;
	
	@Column(name = "transactioncompleted")
	private Boolean transactioncompleted;
	
	@Column(name = "cardnumber")
	private String cardnumber;
	
	@Column(name = "premiumamountpaid")
	private Double premiumamountpaid;

	public Long getTransaction_details_id() {
		return transaction_details_id;
	}

	public void setTransaction_details_id(Long transaction_details_id) {
		this.transaction_details_id = transaction_details_id;
	}

	public Long getSsn() {
		return ssn;
	}

	public void setSsn(Long ssn) {
		this.ssn = ssn;
	}

	public String getPolicytype() {
		return policytype;
	}

	public void setPolicytype(String policytype) {
		this.policytype = policytype;
	}

	public String getPaymenttype() {
		return paymenttype;
	}

	public void setPaymenttype(String paymenttype) {
		this.paymenttype = paymenttype;
	}

	public Boolean getTransactioncompleted() {
		return transactioncompleted;
	}

	public void setTransactioncompleted(Boolean transactioncompleted) {
		this.transactioncompleted = transactioncompleted;
	}

	public String getCardnumber() {
		return cardnumber;
	}

	public void setCardnumber(String cardnumber) {
		this.cardnumber = cardnumber;
	}

	public Double getPremiumamountpaid() {
		return premiumamountpaid;
	}

	public void setPremiumamountpaid(Double premiumamountpaid) {
		this.premiumamountpaid = premiumamountpaid;
	}
	
	
	
	
	
	

}
