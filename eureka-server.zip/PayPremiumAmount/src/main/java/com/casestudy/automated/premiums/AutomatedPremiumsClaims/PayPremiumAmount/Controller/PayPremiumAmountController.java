package com.casestudy.automated.premiums.AutomatedPremiumsClaims.PayPremiumAmount.Controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;



import com.casestudy.automated.premiums.AutomatedPremiumsClaims.PayPremiumAmount.Service.PayPremiumService;
import com.casestudy.automated.premiums.AutomatedPremiumsClaims.PayPremiumAmount.model.MessageResponseDO;
import com.casestudy.automated.premiums.AutomatedPremiumsClaims.PayPremiumAmount.model.PaymentDetail;
import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;






@RestController
public class PayPremiumAmountController {
	private Logger logger = LoggerFactory.getLogger(this.getClass());
	
	@Autowired
	PayPremiumService payPremiumService;
	
	@Autowired
	MessageResponseDO responseDo;
	
	@RequestMapping(value="/paypremiumamount",method = RequestMethod.POST)
	@HystrixCommand(fallbackMethod = "getDataFallBack")
	public MessageResponseDO paypremium(@RequestBody PaymentDetail details,BindingResult result) {
		logger.info("Inside PayPremiumAmount service starts ");
		Long ssn = details.getSsn();
		Double amount = details.getPremiumAmount();
		String policytype = details.getPolicyType();
		String paymentType = details.getPaymentType();
		String cardNumber = details.getCardNumber();
		responseDo = payPremiumService.payPremiummethod(ssn,policytype,amount,paymentType,cardNumber);		 
		logger.info("Inside PayPremiumAmount service ends ");
		return responseDo;
	
	}
	
	
	public MessageResponseDO getDataFallBack(@RequestBody PaymentDetail details,BindingResult result) {
		logger.info("Inside PayPremiumAmount service FallBack method starts ");
		responseDo.setMessage("FallBack");		
		logger.info("Inside PayPremiumAmount service FallBack method ends ");
		return responseDo;
	}

}
