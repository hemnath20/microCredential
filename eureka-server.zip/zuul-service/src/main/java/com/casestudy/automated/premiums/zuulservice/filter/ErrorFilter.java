package com.casestudy.automated.premiums.zuulservice.filter;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.netflix.zuul.ZuulFilter;

public class ErrorFilter extends ZuulFilter {
	
	private Logger logger = LoggerFactory.getLogger(this.getClass());
	
	@Override
	public String filterType() {
		logger.info("Inside Zuul filterType");
		return "error";
	}

	@Override
	public int filterOrder() {
		logger.info("Inside Zuul filterOrder");
		return 0;
	}

	@Override
	public boolean shouldFilter() {
		logger.info("Inside Zuul shouldFilter");
		return true;
	}

	@Override
	public Object run() {
		logger.info("Inside Zuul run method");

		return null;
	}

}
