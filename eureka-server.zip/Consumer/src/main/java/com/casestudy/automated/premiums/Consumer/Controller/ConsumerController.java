package com.casestudy.automated.premiums.Consumer.Controller;

import java.io.IOException;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.client.ServiceInstance;
import org.springframework.cloud.client.discovery.DiscoveryClient;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

public class ConsumerController {
	
	private Logger logger = LoggerFactory.getLogger(this.getClass());
	
	
	@Autowired
	private DiscoveryClient premiumCalculationDiscoveryClient;
	public void getPremiumCalculation() throws RestClientException, IOException {
		
		List<ServiceInstance> instances=premiumCalculationDiscoveryClient.getInstances("zuul-service");
		ServiceInstance serviceInstance=instances.get(0);
		
		String baseUrl=serviceInstance.getUri().toString();
		
		baseUrl=baseUrl+"/automatedpremiumsclaims/premiumcalculation/{ssn}";
		
		RestTemplate restTemplate = new RestTemplate();
		ResponseEntity<String> response=null;
		try{
		response=restTemplate.exchange(baseUrl,
				HttpMethod.GET, getHeaders(),String.class);
		}catch (Exception ex)
		{
			logger.info("Exception caught while invoking the service ", ex.getMessage());
		}
		System.out.println(response.getBody());
	}
	
	@Autowired
	private DiscoveryClient premiumAmountDiscoveryClient;
	public void payPremiumAmount() throws RestClientException, IOException {
		
		List<ServiceInstance> instances=premiumAmountDiscoveryClient.getInstances("zuul-service");
		ServiceInstance serviceInstance=instances.get(0);
		
		String baseUrl=serviceInstance.getUri().toString();
		
		baseUrl=baseUrl+"/paypremium/paypremiumamount";
		
		RestTemplate restTemplate = new RestTemplate();
		ResponseEntity<String> response=null;
		try{
		response=restTemplate.exchange(baseUrl,
				HttpMethod.GET, getHeaders(),String.class);
		}catch (Exception ex)
		{
			logger.info("Exception caught while invoking the service ", ex.getMessage());
		}
		System.out.println(response.getBody());
	}
	
	
	@Autowired
	private DiscoveryClient fileClaimDiscoveryClient;
	public void fileClaim() throws RestClientException, IOException {
		
		List<ServiceInstance> instances=fileClaimDiscoveryClient.getInstances("zuul-service");
		ServiceInstance serviceInstance=instances.get(0);
		
		String baseUrl=serviceInstance.getUri().toString();
		
		baseUrl=baseUrl+"/fileclaim/fileAclaim";
		
		RestTemplate restTemplate = new RestTemplate();
		ResponseEntity<String> response=null;
		try{
		response=restTemplate.exchange(baseUrl,
				HttpMethod.GET, getHeaders(),String.class);
		}catch (Exception ex)
		{
			logger.info("Exception caught while invoking the service ", ex.getMessage());
		}
		System.out.println(response.getBody());
	}


	private static HttpEntity<?> getHeaders() throws IOException {
		HttpHeaders headers = new HttpHeaders();
		headers.set("Accept", MediaType.APPLICATION_JSON_VALUE);
		return new HttpEntity<>(headers);
	}

}
